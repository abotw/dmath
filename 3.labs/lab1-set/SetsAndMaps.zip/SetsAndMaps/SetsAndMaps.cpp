#include "console.h"
#include "hashmap.h"
#include "hashset.h"
#include "map.h"
#include "set.h"
#include <iostream>
using namespace std;

int main() {
    Set<string> friends;
    friends.add("cynthia");
    friends.add("jonathan");
    friends.add("chris");
    friends.add("julie");
    cout << boolalpha << friends.contains("voldemort") << noboolalpha << endl;
    for (string person : friends) {
        cout << person << endl;
    }

    // tally votes:
    // (M)ilk, (S)tokes, (R)ogers
    string allVotes = "MMMRMSSMSSMMMMMRRMMMMRRRMMM";

    Map<char, int> voteTally;
    for (char v : allVotes) {
        voteTally[v]++;
        // could have done:
        // int& currentTotal = voteTally[v];
        // currentTotal++;
    }

    // loop over the map
    for (char initial : voteTally) {
        int numVotes = voteTally[initial];
        cout << initial << ": " << numVotes << " votes" << endl;
    }
    return 0;
}
